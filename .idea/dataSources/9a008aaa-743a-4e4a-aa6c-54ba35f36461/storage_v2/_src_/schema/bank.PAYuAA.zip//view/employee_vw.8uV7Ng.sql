create view employee_vw as
  select
    `bank`.`employee_vw_table`.`emp_id` AS `emp_id`,
    `bank`.`employee_vw_table`.`fname`  AS `fname`,
    `bank`.`employee_vw_table`.`lname`  AS `lname`
  from `bank`.`employee_vw_table`;

